<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Your Orders</name>
   <tag></tag>
   <elementGuidId>3cf34ad6-ac31-48d3-8894-cb28b30a0c4a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.a-spacing-none.ya-card__heading--rich.a-text-normal</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[2]/div/a/div/div/div/div[2]/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>795f5f30-ba72-447d-a63a-3a9d30a3aead</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none ya-card__heading--rich a-text-normal</value>
      <webElementGuid>20d47e81-49ef-45e5-9b3d-7558cc8c6c90</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Your Orders
                </value>
      <webElementGuid>6b50800e-878f-4d02-a482-2ed9071328f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span9 a-span-last&quot;]/h2[@class=&quot;a-spacing-none ya-card__heading--rich a-text-normal&quot;]</value>
      <webElementGuid>815c2cb7-3706-49bc-830e-5daef65c656c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[2]/div/a/div/div/div/div[2]/h2</value>
      <webElementGuid>d284bce4-4b5e-423e-8f5c-e95b97dfe1e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>eec2ce7c-45eb-46be-b0bf-57f8a18a4fb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
                    Your Orders
                ' or . = '
                    Your Orders
                ')]</value>
      <webElementGuid>adac982d-4cb7-477b-8a3b-437bdd9fcba8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
