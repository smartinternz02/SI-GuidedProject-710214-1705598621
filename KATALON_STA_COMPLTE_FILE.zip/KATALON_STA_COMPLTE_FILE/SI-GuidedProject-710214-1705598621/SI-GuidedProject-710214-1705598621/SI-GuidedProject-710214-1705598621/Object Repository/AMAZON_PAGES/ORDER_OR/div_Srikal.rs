<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Srikal</name>
   <tag></tag>
   <elementGuidId>5bba4604-ff56-4bc4-9999-018efaff4fef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-column.a-span11.a-spacing-base.aok-break-word</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='profile-pick-actor-button-0']/a/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ce6b8279-ed3c-4645-b8ec-f9410cb64724</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-column a-span11 a-spacing-base aok-break-word</value>
      <webElementGuid>4d0117c9-7e9c-4500-81f5-cec2c372534b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
            
            
                
                    Srikal
                
            
        
    </value>
      <webElementGuid>8c9bbb98-56aa-42e1-8c13-7801cc3d60c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;profile-pick-actor-button-0&quot;)/a[@class=&quot;a-color-base a-link-normal linkStylingHover&quot;]/div[@class=&quot;a-row a-spacing-top-small a-grid-vertical-align a-grid-center a-ws-row&quot;]/div[@class=&quot;a-column a-span11 a-spacing-base aok-break-word&quot;]</value>
      <webElementGuid>10c04bac-08c0-49ed-8e39-9fd8ead2e90e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[@id='profile-pick-actor-button-0']/a/div/div</value>
      <webElementGuid>f8105a54-7584-4be2-a934-9640132713e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/div</value>
      <webElementGuid>9fe8ea69-0a1d-4fd2-9964-819ad504e38e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
        
            
            
                
                    Srikal
                
            
        
    ' or . = '
        
        
            
            
                
                    Srikal
                
            
        
    ')]</value>
      <webElementGuid>08e80e40-6700-4149-8d05-7b3cb28ef8a0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
