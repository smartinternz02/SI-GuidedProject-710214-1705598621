<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_0                                                Cart</name>
   <tag></tag>
   <elementGuidId>d787cf82-ac1a-4f1a-95a6-df1808fc6ef1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='nav-cart']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#nav-cart</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a901a3eb-e22c-45f2-a23d-461de34a286e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/gp/cart/view.html?ref_=nav_cart</value>
      <webElementGuid>d91c2ade-4287-4626-8632-8ee954cf1a4f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>0 items in cart</value>
      <webElementGuid>ef0dd9a7-aaa0-4e5e-b517-a9a62e01becc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-a nav-a-2 nav-progressive-attribute</value>
      <webElementGuid>39744399-aed2-46bd-8838-71c70f339656</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-cart</value>
      <webElementGuid>6d8b6bea-8da0-472b-95b3-32ba6cc934fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      0
      
    
    
      
        
      
      
        Cart
        
      
    
  </value>
      <webElementGuid>949dddcb-c33f-4d44-ac43-14a34a0ba149</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-cart&quot;)</value>
      <webElementGuid>40a9e0e8-a392-442e-a7f5-1ef8323f0d2a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='nav-cart']</value>
      <webElementGuid>eaa43430-4879-497f-84f0-594059c0b2e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-tools']/a[5]</value>
      <webElementGuid>0a989d61-e801-4e33-948f-25a063a7aef2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/gp/cart/view.html?ref_=nav_cart')]</value>
      <webElementGuid>02a64108-1dd6-4b34-af46-f0aa2ba18f9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[5]</value>
      <webElementGuid>50c5bb81-3ce8-4984-883e-f27825c5e1a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/gp/cart/view.html?ref_=nav_cart' and @id = 'nav-cart' and (text() = '
    
      0
      
    
    
      
        
      
      
        Cart
        
      
    
  ' or . = '
    
      0
      
    
    
      
        
      
      
        Cart
        
      
    
  ')]</value>
      <webElementGuid>0dbbea33-7b60-495e-9964-7be3331e0b40</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
